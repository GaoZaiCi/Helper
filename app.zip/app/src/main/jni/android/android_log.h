//
// Created by jiangwei1-g on 2016/5/23.
//

#ifndef ENCRYPTDEMO_ENCRYPT_H
#define ENCRYPTDEMO_ENCRYPT_H

#include <android/log.h>

#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, "FMP_Helper", __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,"FMP_Helper", __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, "FMP_Helper", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "FMP_Helper", __VA_ARGS__)


#endif //ENCRYPTDEMO_ENCRYPT_H

