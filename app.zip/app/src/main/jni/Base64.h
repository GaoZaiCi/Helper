//
// Created by Gao在此 on 2020/3/28.
//

#ifndef HELPER_BASE64_H
#define HELPER_BASE64_H
unsigned char *base64_encode(unsigned char *str);
unsigned char *base64_decode(unsigned char *code);
#endif //HELPER_BASE64_H
