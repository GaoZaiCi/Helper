package com.fmp.library;

/**
 * Project Name:EasyProtector
 * Package Name:com.lahm.library
 * Created by lahm on 2018/7/25 14:22 .
 */
public interface VirtualCheckCallback {
    void findSuspect();
}
