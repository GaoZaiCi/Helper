package com.fmp.core.push;

public class PushHotFix {
    private int code;
    private String url;
    private boolean forced;

    public int getCode() {
        return code;
    }

    public String getUrl() {
        return url;
    }

    public boolean isForced() {
        return forced;
    }
}
